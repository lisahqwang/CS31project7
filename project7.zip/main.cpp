//UID: 105502901 
//name: Lisa Wang
//class: CS31 professor Huang




#include <iostream>
#include <string>
#include <cassert>
#include "RandomNumber.h"
#include "Die.h"
#include "Player.h"
#include "Board.h" 
#include "BeatThat.h"                  

int main()
{
     //used the project page's code for main.cpp
    using namespace std;
    using namespace cs31;
    // test code
    Die d1; d1.setValue(1);
    Die d2; d2.setValue(2);
    Die d3; d3.setValue(3);
    Die d4; d4.setValue(4);
    Die d5; d5.setValue(5);
    Die d6; d6.setValue(6);

    BeatThat game;
    // 5 forced rounds of play...
    game.humanPlay(d1, d2);
    game.computerPlay(d2, d1);
    game.endTurn();
    assert(game.determineGameOutcome() == cs31::BeatThat::GAMENOTOVER);
    game.humanPlay(d4, d4);
    game.computerPlay(d6, d1);
    game.endTurn();
    assert(game.getComputer().getRoundsWon() == 1);
    game.humanPlay(d6, d5);
    game.computerPlay(d6, d2);
    game.endTurn();
    assert(game.getHuman().getRoundsWon() == 1);
    game.humanPlay(d3, d3);
    game.computerPlay(d3, d3);
    game.endTurn();
    game.humanPlay(d5, d4);
    game.computerPlay(d4, d5);
    game.endTurn();
    assert(game.isGameOver() == true);
    assert(game.getHuman().getRoundsWon() == 1);
    assert(game.getComputer().getRoundsWon() == 1);
    assert(game.determineGameOutcome() == cs31::BeatThat::TIEDGAME);
    cout << "all tests passed!" << endl;
    return 0;

}