//
//  Player.cpp
//  BeatThat
//

// skeleton logic


#include "Player.h"

#include <iostream>

namespace cs31
{
    // Each Player has two six-sided dies and tracks how many rounds have been won
    Player::Player() : mDie1(6), mDie2(6), mRoundsWon(0)
    {
        //empty constructor 
    }

    void Player::roll(Die d1, Die d2)
    {
        // cheating...
        mDie1 = d1;
        mDie2 = d2;
    }

    // TODO: randomly roll each of the Player's die
    void Player::roll()
    {
        //since there are two die, we must have the first die be rolled using the RandomNumber class function roll to roll the first die
        //now we roll the second die
        mDie1.roll();
        int roll_val1 = mDie1.getValue();
        //we must get the value from the roll, and then set the value using .setValue function
        mDie1.setValue(roll_val1);
        mDie2.roll();
        int roll_val2 = mDie2.getValue();
        //same procedure as before, but for the second die 
        mDie2.setValue(roll_val2);
    }

    // trivial getter
    Die Player::getDie1() const
    {
        return(mDie1);
    }

    // trivial getter
    Die Player::getDie2() const
    {
        return(mDie2);
    }

    // TODO: called to indicate that this Player has won a round of play
    //       it should increment the RoundsWon counter
    void Player::wonARound()
    {
        //indicate that the player won, and change the value stored in the variable mRoundsWon to one more
        mRoundsWon++;
    }

    // TODO: trivial getter
    int  Player::getRoundsWon() const
    {
        // just to get the skeleton to build...
        //a simple mutator, returns the value stored in the mRoundsWon variable 
        return mRoundsWon;
    }

    // TODO: identify and return the die with the largest value
    Die  Player::largestDie() const
    {
        // just to get the skeleton to build...
        if (mDie1.getValue() >= mDie2.getValue()) {
            return mDie1;
        }
        return mDie2;
    }

    // TODO: identify and return the die with the largest value
    Die  Player::smallestDie() const
    {
        // just to get the skeleton to build...
        if (mDie1.getValue() <= mDie2.getValue()) { //the conditional statement that upon comparing the values of die1 and die2, 
            //if the first die is larger in value than the second, then the second die is the smallest
            //if the first die is smaller in value than the second, then the first die is the smallest
            return mDie1;
        }

        return mDie2;
        //must return a die, so not put inside a if statement 
    }

    // for testing purposes
    std::string Player::whatWasRolled()
    {
        std::string s = "";
        s += "Die1: ";
        s += std::to_string(mDie1.getValue());
        s += " Die2: ";
        s += std::to_string(mDie2.getValue());
        return(s);
    }



}

